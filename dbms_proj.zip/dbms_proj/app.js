var express    = require("express"),
	app        = express(),
	methodOverride = require("method-override"),
	mongoose   = require("mongoose"),
	Advertiser = require("./models/advertisers"),
	Host       = require("./models/hosts"),
	bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
mongoose.connect("mongodb://localhost/ad_manager_v1");
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));

app.get("/",function(req,res){
	res.render("landing");
});

app.get("/hosts",function(req,res){
	Host.find({}, function(err, allHosts){
       if(err){
           console.log(err);
       } else {
          res.render("hosts",{hosts:allHosts});
       }
    });
});

app.get("/advertisers",function(req,res){
	Advertiser.find({}, function(err, allAdvertisers){
       if(err){
           console.log(err);
       } else {
          res.render("advertisers",{advertisers:allAdvertisers});
       }
    });
});

app.post("/hosts",function(req,res){
	var name = req.body.sitename;
	var image = req.body.image;	
	var newHost = {name : name,image: image};
	
	Host.create(newHost, function(err, newlyCreated){
        if(err){
            console.log(err);
        } else {
            res.redirect("/hosts");
        }
    });
});

app.post("/advertisers",function(req,res){
	var name = req.body.brandname;
	var image = req.body.image;	
	var description = req.body.description;
	var newAdvertiser = {name : name,image : image,description:description};
	Advertiser.create(newAdvertiser, function(err, newlyCreated){
        if(err){
            console.log(err);
        } else {
            res.redirect("/advertisers");
        }
    });
});

app.get("/hosts/new",function(req,res){
	res.render("newhost");
});

app.get("/advertisers/new",function(req,res){
	res.render("newad");
});

app.get("/advertisers/:id", function(req, res){
    //find the campground with provided ID
    Advertiser.findById(req.params.id, function(err, foundAdvertiser){
        if(err){
            console.log(err);
        } else {
            //render show template with that campground
            res.render("showAd", {advertiser: foundAdvertiser});
        }
    });
});

app.get("/hosts/:id", function(req, res){
    //find the campground with provided ID
    Host.findById(req.params.id, function(err, foundHost){
        if(err){
            console.log(err);
        } else {
            //render show template with that campground
            res.render("showHost", {host: foundHost});
        }
    });
});





app.listen(3000, () => console.log('Ad manager server has started'));