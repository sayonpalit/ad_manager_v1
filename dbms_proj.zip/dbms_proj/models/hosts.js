var mongoose=require("mongoose");
var hostschema = new mongoose.Schema({

name:String,
image:String,
description:String,
advertiser:[
   	{
    type:mongoose.Schema.Types.ObjectId,
     ref:"Advertisers" 
 	}
  ]

});
module.exports=mongoose.model("Hosts",hostschema);
