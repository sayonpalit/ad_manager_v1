var mongoose=require("mongoose");
var advertiserschema = new mongoose.Schema({

name:String,
image:String,
description:String
 

});

module.exports=mongoose.model("Advertisers",advertiserschema);
